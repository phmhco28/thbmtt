/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thuchanh;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.math.BigInteger;
import java.security.interfaces.RSAPrivateCrtKey;

/**
 *
 * @author Administrator
 */
public class Dec_RSA {
    static String decrypt = "";
    
    public static String decryption() throws Exception{
        // dọc văn bản đã mã hóa
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("D:\\Enc_RSA.dat")));
        String ctext = in.readLine();
        // chuyển sang kiểu biginteger
        BigInteger c = new BigInteger(ctext);
        // đọc khóa private key
        FileInputStream f = new FileInputStream("D:\\Skey_RSA_priv.dat");
        // Sử dụng hàm readObject của ObjectInputStream
        // để đọc dữ liệu từ tập tin nhị phân lên
        // Thứ tự đọc cần đảm bảo đúng thứ tự ghi 
        ObjectInputStream b = new ObjectInputStream(f);
        RSAPrivateCrtKey prk = (RSAPrivateCrtKey)b.readObject();
        BigInteger d = prk.getPrivateExponent();
        BigInteger n = prk.getModulus();
        System.out.println("d="+d);
        System.out.println("n="+n);
        BigInteger m = c.modPow(d, n);
        
        System.out.println("m="+m);
        byte[] mt = m.toByteArray();
        System.out.println("PlainText is");
        for (int i = 0; i < mt.length; i++) {
            System.out.print((char)mt[i]);
            decrypt+=(char)mt[i];
        }
        return decrypt;
    }
}
