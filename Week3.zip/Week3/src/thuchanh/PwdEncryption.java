/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thuchanh;

import java.math.BigInteger;
import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class PwdEncryption {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        String nhash;
        BigInteger[] ciphertext = null;
        BigInteger n = null;
        BigInteger d = null;
        String password = "";
        System.out.println("Enter text to be encrypted: ");
        password = in.nextLine();
        
        
        RSA rsa = new RSA(8);
        n=rsa.getN();
        d=rsa.getD();
        ciphertext = rsa.encrypt(password);
        
        StringBuffer bf = new StringBuffer();
        for(int i =0; i < ciphertext.length;i++){
            bf.append(ciphertext[i].toString(10).toUpperCase());
            
            if(1 != ciphertext.length -1){
                System.out.print(" ");
            }
        }
        
        String message = bf.toString();
        System.out.println();
        System.out.println("Encrypted Message: " + message);
        
        String dhash = rsa.decrypt(ciphertext, d, n);
        System.out.println();
        System.out.println("Decrypted Message: " + dhash);
    }
    
}
