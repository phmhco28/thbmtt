/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pwdencryption;

import java.math.BigInteger;
import java.util.Random;
import java.io.*;


/**
 *
 * @author 01642
 */
public class RSA {
    /**    
     * Độ dài bit của mỗi số nguyên tố
     */
    int primeSize;
    
    /**   
     * Hai số nguyên tố phân biệt p và q
     */
    BigInteger p ,q;
    
    /**
     * Modulus N
     * N = p * q
     */
    BigInteger N;
    
    /**
     * r = (p-1) * (q-1)
     */
    BigInteger r;
    
    /**
     * Khóa mã E và khóa giải mã D
     */
    BigInteger E, D;
    
    public RSA(){
        
    }
    
    /**
     * contructor
     */
    
    public RSA(int primeSize){
        this.primeSize = primeSize;
              
        //Tạo hai số nguyên tố p và q khác nhau
        generatePrimeNumbers();
        
        //Tạo ra khóa công khai E, N và khóa riêng tư D
        generatePublicPrivateKeys();
    }
    
    //tạo ra 2 số nguyên tố ngẫu nhiên
    public void generatePrimeNumbers(){
        //Random random = new Random();
        p = BigInteger.probablePrime(primeSize /2, new Random());     
        do{
            q = BigInteger.probablePrime(primeSize /2, new Random());
        }while(q.compareTo(p) == 0);
      
    }
    
    /**
     * Tạo ra khóa công khai và khóa riêng tư
     */
    public void generatePublicPrivateKeys(){
        // N = p * q
        N = p.multiply(q);
        
        //r = (p-1) * (q-1)
        r = p.subtract(BigInteger.valueOf(1));
        r = r.multiply(q.subtract(BigInteger.valueOf(1)));
        
        
        //chọn E nhỏ hơn r
        do{
            E = new BigInteger(2 * primeSize, new Random());
        }
        while((E.compareTo(r) != -1) || 
                (E.gcd(r).compareTo(BigInteger.valueOf(1))!= 0));
        
        //Tính toán D, nghịch đảo của E mod r
        D = E.modInverse(r);
    }
    
    /**
     * Mã hóa bản rõ (Sử dụng khóa công khai)
     * 
     */
    public BigInteger[] encrypt(String message){
        int i;
        byte[] temp = new byte[1];
        
        byte[] digits = message.getBytes();
        
        BigInteger[] bigdigits = new BigInteger[digits.length];
        
        for(i =0; i < bigdigits.length; i++){
            temp[0] = digits[i];
            bigdigits[i] = new BigInteger(temp);
        }
        
        BigInteger[] encrypted = new BigInteger[bigdigits.length];
        
        for(i = 0; i < bigdigits.length; i++){
            encrypted[i] = bigdigits[i].modPow(E, N);
        }
        return (encrypted);
    }
    
    public BigInteger[] encrypt(String message, BigInteger userD, BigInteger userN){
        int i;
        byte[] temp = new byte[1];
        
        byte[] digits = message.getBytes();
        
        BigInteger[] bigdigits = new BigInteger[digits.length];
        
        for(i=0; i< bigdigits.length;i++){
            temp[0] = digits[i];
            bigdigits[i] = new BigInteger(temp);
        }
        
        BigInteger[] encrypted = new BigInteger[bigdigits.length];
        
        for(i=0;i<bigdigits.length;i++){
            encrypted[i] = bigdigits[i].modPow(userD, userN);
        }
        return (encrypted);
    }
    
    /**
     * decrypts the ciphertext (Using private key)
     */
    public String decrypt(BigInteger[] encrypted, BigInteger D, BigInteger N){
        int i;
        
        BigInteger[] decrypted = new BigInteger[encrypted.length];
        
        for(i =0; i < decrypted.length;i++){
            decrypted[i] = encrypted[i].modPow(D, N);
        }
        
        char[] charArray = new char[decrypted.length];
        
        for(i = 0; i < charArray.length;i++){
            charArray[i] = (char)(decrypted[i].intValue());
        }
        return( new String(charArray));
    }
    
    /**
     * get prime number p
     */
    public BigInteger getp(){
        return( p);
    }
    
    /**
     * get prime number q
     */
    public BigInteger getq(){
        return( q);
    }
    
    /**
     * get prime number r
     */
    public BigInteger getr(){
        return( r);
    }
    
    /**
     * get modulus N
     */
    public BigInteger getN(){
        return( N);
    }
    
    /**
     * get public exponent E
     */
    public BigInteger getE(){
        return( E);
    }
    
     /**
     * get public exponent D
     */
    public BigInteger getD(){
        return( D);
    }
    
    /**
     * RSA main program for Unit Testing
     */
    public static void main(String[] args) throws IOException{
     
       int primeSize = 8;
       
       //generate public and private keys
       RSA rsa = new RSA(primeSize);
       
        //System.out.println("Key size: [" + primeSize + "]");
        //System.out.println("");
        
        System.out.println("Generated prime numbers p and q");
        System.out.println("p: [" + rsa.getp().toString(10) + "]");
        System.out.println("q: [" + rsa.getq().toString(10) + "]");
        System.out.println("");
        
        System.out.println("the public key is the pair (N,E) which will be published");
        System.out.println("N: [" + rsa.getN().toString(10).toUpperCase() + "]");
        System.out.println("r: [" + rsa.getr().toString(10).toUpperCase() + "]");
        System.out.println("E: [" + rsa.getE().toString(10).toUpperCase() + "]");
        System.out.println("");
        
        System.out.println("the private key is the pair (N,D) which will be kept priavate");
        System.out.println("N: [" + rsa.getN().toString(10).toUpperCase() + "]");
        System.out.println("D: [" + rsa.getD().toString(10).toUpperCase() + "]");
        System.out.println("");
        
        //get message(plaintext) from user
        System.out.println("Please enter message (plaintext):");
        String plaintext = ( new BufferedReader(new InputStreamReader(System.in))).readLine();
        System.out.println("");
        
        //encrypt message
        BigInteger[] cipherText = rsa.encrypt(plaintext);
        
        System.out.println("CipherText: [");
        for(int i=0;i<cipherText.length;i++){
            //System.out.println(cipherText[i].toString(10).toUpperCase());
            System.out.println(cipherText[i].toString(10));
            if(i != cipherText.length -1){
                 
            }
        }
        System.out.println("]");
        System.out.println("");
        
        RSA rsa1 = new RSA(8);
        
        String recoveredPlaintext = rsa1.decrypt(cipherText, rsa.getD(), rsa.getN());
        
        System.out.println("Recovered plaintext: [" + recoveredPlaintext + "]");
    }
}
