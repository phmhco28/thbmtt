/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mahoakhonggiancongkhai;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.security.interfaces.RSAPublicKey;

/**
 *
 * @author quoct
 */
public class Enc_RSA {
    static String plantext="";

    public Enc_RSA() {
    }
    public Enc_RSA(String plantext) {
        this.plantext=plantext;
    }
    
    public static void main() throws Exception{
        // chuoi can ma hoa
         String s="Hello World";
        if(plantext!="")
            s=plantext;
        // doc file public key

        FileInputStream f = new FileInputStream("D:\\Skey_RSA_pub.dat");
        ObjectInputStream b = new ObjectInputStream(f);
        // Sử dụng hàm readObject của ObjectInputStream
        // đẻ dọc dữ liệu từ tập tin nhị phân lên
        // Thứ tuẹ đoc cần đảm bảo đúng với thứ tự ghi
        RSAPublicKey pbk = (RSAPublicKey)b.readObject();
        BigInteger e = pbk.getPublicExponent();
        BigInteger n = pbk.getModulus();
        System.out.println("e="+e);
        System.out.println("n="+n);
        byte ptext[] = s.getBytes("UTF8");
        BigInteger m = new BigInteger(ptext);
        BigInteger c =m.modPow(e, n);
        System.out.println("c="+c);
        String cs = c.toString();
        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("d:\\Enc_RSA.dat")));
        out.write(cs,0,cs.length());
        out.close();
    }
}
