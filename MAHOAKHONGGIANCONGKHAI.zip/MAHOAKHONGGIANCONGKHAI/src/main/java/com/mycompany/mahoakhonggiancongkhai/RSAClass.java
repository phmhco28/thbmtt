/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mahoakhonggiancongkhai;

import java.math.BigInteger;
import java.util.Random;

/**
 *
 * @author quoct
 */
public class RSAClass {
    int primeSize;
    BigInteger p,q,N,r;
    BigInteger E,D;
    Random random = new Random();
    public RSAClass(){
        
    }
    public RSAClass(int priseSize){
        this.primeSize = priseSize;
        
        generatePrimeNumbers();
        generatePublicPrivateKeys();
    }
    public void generatePrimeNumbers(){
        p=BigInteger.probablePrime(primeSize/2, random);
        
        do{
            q=BigInteger.probablePrime(primeSize/2, random);
        }while(q.compareTo(p)==0);
        
    }
    public void generatePublicPrivateKeys(){
        N =p.multiply(q);
         r=p.subtract(BigInteger.valueOf(1));
         r=r.multiply(q.subtract(BigInteger.valueOf(1)));
         
         do{
              E = new BigInteger(2*primeSize,new Random());
         }while((E.compareTo(r)!=1)||(E.gcd(r).compareTo(BigInteger.valueOf(1))!=0));
         
         D=E.modInverse(r);
    }
    
    public BigInteger[] encrypt (String message){
        int i;
        byte[] temp = new byte[1];
        byte[] digits = message.getBytes();
        BigInteger[] bigdigits = new BigInteger[digits.length];
        for(i =0 ; i<bigdigits.length;i++){
            temp[0]=digits[i];
            bigdigits[i]=new BigInteger(temp);
            
        }
        BigInteger[] encrypted = new BigInteger[bigdigits.length];
        for(i=0 ; i<bigdigits.length;i++){
            
        }
        
    }
}
